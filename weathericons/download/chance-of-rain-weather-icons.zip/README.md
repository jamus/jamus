#Chance of Rain — Weather Icons
28 beautifully simple weather icons for user interface application. 

Designed and produced by <a href="twitter.com/jamusreynolds">@jamusreynolds</a>.

Visit <a href="http://www.jamus.co.uk/weathericons/">jamus.co.uk/weathericons/</a> for more information.

#License
All released for free under the license CC BY-SA 3.0.

#Download and use
These are licensed under CC BY 3.0. This means you can use them for free so long as you display a small attribute somewhere.
"Weather icons by Jamie Reynolds — @jamusreynolds" would be fine, including a link to jamus.co.uk/weathericons/ would be nicer. :)